import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

class NeuralNetwork:
    def __init__(self, input_dim, hidden_dim, output_dim, learning_rate=0.01, iterations=1500):
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.cost_history = []

        # Initialize weights and biases
        self.weights1 = np.random.randn(input_dim, hidden_dim) * 0.01
        self.bias1 = np.zeros((1, hidden_dim))
        self.weights2 = np.random.randn(hidden_dim, output_dim) * 0.01
        self.bias2 = np.zeros((1, output_dim)) 

    def sigmoid(self, z):
        """Sigmoid activation function."""
        z = np.clip(z, -500, 500)  # Prevent overflow
        return 1 / (1 + np.exp(-z))
    
    def sigmoid_derivative(self, z):
        """Derivative of sigmoid."""
        return z * (1 - z)

    def binary_cross_entropy(self, y_true, y_pred):
        """Binary cross-entropy loss function."""
        epsilon = 1e-8  # Small value to avoid log(0)
        return -np.mean(y_true * np.log(y_pred + epsilon) + (1 - y_true) * np.log(1 - y_pred + epsilon))

    def forward_propagation(self, X):
        """Perform forward propagation."""
        self.Z1 = np.dot(X, self.weights1) + self.bias1
        self.A1 = self.sigmoid(self.Z1)
        self.Z2 = np.dot(self.A1, self.weights2) + self.bias2
        self.A2 = self.sigmoid(self.Z2)
        return self.A2

    def backward_propagation(self, X, y, y_pred):
        """Perform backward propagation."""
        m = X.shape[0]  # Number of samples

        # Output layer gradients
        dZ2 = y_pred - y
        dW2 = np.dot(self.A1.T, dZ2) / m
        db2 = np.sum(dZ2, axis=0, keepdims=True) / m

        # Hidden layer gradients
        dA1 = np.dot(dZ2, self.weights2.T)
        dZ1 = dA1 * self.sigmoid_derivative(self.A1)
        dW1 = np.dot(X.T, dZ1) / m
        db1 = np.sum(dZ1, axis=0, keepdims=True) / m

        # Update weights and biases
        self.weights1 -= self.learning_rate * dW1
        self.bias1 -= self.learning_rate * db1
        self.weights2 -= self.learning_rate * dW2
        self.bias2 -= self.learning_rate * db2

    def train(self, X, y):
        """Train the neural network."""
        for i in range(self.iterations):
            # Forward propagation
            y_pred = self.forward_propagation(X)

            # Compute cost
            cost = self.binary_cross_entropy(y, y_pred)
            self.cost_history.append(cost)

            # Backward propagation
            self.backward_propagation(X, y, y_pred)

            # Print cost every 100 iterations
            if i % 100 == 0:
               print(f"Iteration {i} | Cost: {cost}")

    def predict(self, X):
        """Predict binary labels for input data."""
        y_pred = self.forward_propagation(X)
        return (y_pred > 0.5).astype(int)

# # Load and preprocess the dataset
# train_data = pd.read_csv('nn_train.csv')
# X = train_data.drop(columns=['ID', 'binary_label', 'class_label']).values
# y = train_data['binary_label'].values.reshape(-1, 1)

def clean_data(X, y):
    print("Are there any NaN values in X? ", np.isnan(X).any())
    print("Are there any NaN values in y? ", np.isnan(y).any())
    print("Are there any infinite values in X? ", np.isinf(X).any())
    print("Are there any infinite values in y? ", np.isinf(y).any())

    col_nan_mask = np.isnan(X).all(axis=0)  # Columns that are entirely NaN
    print("Columns entirely NaN:", np.where(col_nan_mask)[0])
    X = X[:, ~col_nan_mask]  # Drop these columns

    col_means = np.nanmean(X, axis=0)  # Compute column means, ignoring NaN
    inds = np.where(np.isnan(X))  # Find indices where NaN values exist
    X[inds] = np.take(col_means, inds[1])  # Replace NaN values with column means

    nan_columns = np.isnan(X).any(axis=0)  # Identify columns with any NaN values
    print("Columns with NaN values:", np.where(nan_columns)[0])

    print("Are there any NaN values in X after final cleaning? ", np.isnan(X).any())
    print("Feature-wise mean:\n", np.mean(X, axis=0))
    print("Feature-wise std deviation:\n", np.std(X, axis=0))

    valid_indices = ~np.isnan(y).flatten()  # Find rows without NaN in y
    X = X[valid_indices]
    y = y[valid_indices]

    # Normalize input features
    scaler = StandardScaler()
    X_normalized = scaler.fit_transform(X)

    return (X_normalized, y)

# X, y = clean_data(X, y)

# # Initialize and train the neural network
# input_dim = X.shape[1]
# hidden_dim = 4  # Number of neurons in the hidden layer
# output_dim = 1  # Binary output

# nn = NeuralNetwork(input_dim=input_dim, hidden_dim=hidden_dim, output_dim=output_dim, learning_rate=0.01, iterations=1500)
# nn.train(X, y)

# # Plot cost vs iterations
# plt.plot(range(len(nn.cost_history)), nn.cost_history)
# plt.title("Cost vs Iterations")
# plt.xlabel("Iterations")
# plt.ylabel("Cost")
# plt.grid()
# plt.show()

# # Combine X_normalized and y into a single DataFrame
# # Create a DataFrame with the normalized features and the labels
# cleaned_data = pd.DataFrame(X_normalized, columns=[f'feature_{i+1}' for i in range(X_normalized.shape[1])])
# cleaned_data['binary_label'] = y

# # Save the DataFrame to a CSV file
# cleaned_data.to_csv('cleaned_data.csv', index=False)