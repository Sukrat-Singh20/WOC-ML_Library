import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split  # For data splitting

class LogisticRegressionOvR:
    def __init__(self, num_classes, lr=0.01, epochs=100):
        self.num_classes = num_classes
        self.lr = lr
        self.epochs = epochs
        self.weights = None
        self.biases = None
        self.cost_history = []

    @staticmethod
    def sigmoid(z):
        return 1 / (1 + np.exp(-z))

    @staticmethod
    def compute_cost(y_true, y_pred):
        # Binary cross-entropy loss
        m = len(y_true)
        cost = -(1 / m) * np.sum(y_true * np.log(y_pred + 1e-15) + (1 - y_true) * np.log(1 - y_pred + 1e-15))
        return cost

    def train(self, X, y):
        m, n = X.shape
        self.weights = np.zeros((self.num_classes, n))
        self.biases = np.zeros(self.num_classes)
        
        for epoch in range(self.epochs):
            epoch_cost = 0
            for c in range(self.num_classes):
                y_binary = (y == c).astype(int)
                z = np.dot(X, self.weights[c]) + self.biases[c]
                predictions = self.sigmoid(z)

                # Compute cost for this class
                cost = self.compute_cost(y_binary, predictions)
                epoch_cost += cost

                # Gradient Descent
                error = predictions - y_binary
                self.weights[c] -= self.lr * np.dot(error, X) / m
                self.biases[c] -= self.lr * np.sum(error) / m
            
            self.cost_history.append(epoch_cost)
            # Print cost per epoch
            if(epoch % 10 == 0): print(f"Epoch {epoch + 1}/{self.epochs}, Cost: {epoch_cost:.4f}")

    def predict(self, X):
        z = np.dot(X, self.weights.T) + self.biases
        probabilities = self.sigmoid(z)
        return np.argmax(probabilities, axis=1)

    def visualize_cost(self):
        # Plot cost vs iterations
        plt.plot(range(len(self.cost_history)), self.cost_history)
        plt.title("Cost vs Iterations")
        plt.xlabel("Iterations")
        plt.ylabel("Cost")
        plt.grid()
        plt.show()

# # Load the dataset
# data = pd.read_csv('multi_classification_train.csv')

# # Extract features and target
# X = data.iloc[:, 1:-1].values  # Features (exclude ID and Class)
# y = data['Class'].values  # Target

# # Normalize features
# X = (X - X.mean(axis=0)) / X.std(axis=0)

# # Split the data into training and testing sets
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# # Train the model
# num_classes = len(np.unique(y_train))
# model = LogisticRegressionOvR(num_classes=num_classes, lr=0.01, epochs=100)
# model.train(X_train, y_train)

# # Evaluate the model
# y_train_pred = model.predict(X_train)
# y_test_pred = model.predict(X_test)

# train_accuracy = np.mean(y_train_pred == y_train) * 100
# test_accuracy = np.mean(y_test_pred == y_test) * 100

# print(f"Training Accuracy: {train_accuracy:.2f}%")
# print(f"Testing Accuracy: {test_accuracy:.2f}%")

# # Plot training and testing accuracy
# plt.bar(['Train Accuracy', 'Test Accuracy'], [train_accuracy, test_accuracy], color=['blue', 'orange'])
# plt.title('Model Accuracy')
# plt.ylabel('Accuracy (%)')
# plt.show()

# model.visualize_cost()