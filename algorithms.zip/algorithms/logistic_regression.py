import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

class LogisticRegression:
    def __init__(self, learning_rate=0.01, iterations=1000):
        """
        Initializes the Logistic Regression model.

        Parameters:
        - learning_rate: Learning rate for gradient descent.
        - iterations: Number of iterations for training.
        """
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.weights = None
        self.bias = None

    def sigmoid(self, z):
        """
        Sigmoid activation function.
        """
        return 1 / (1 + np.exp(-z))

    def fit(self, X, y):
        """
        Trains the logistic regression model using gradient descent.

        Parameters:
        - X: Training data, a NumPy array of shape (n_samples, n_features).
        - y: Target values, a NumPy array of shape (n_samples,).
        """
        n_samples, n_features = X.shape
        self.weights = np.random.rand(n_features)
        self.bias = np.random.rand()
        self.cost_history = []

        for i in range(self.iterations):
            linear_model = np.dot(X, self.weights) + self.bias
            y_predicted = self.sigmoid(linear_model)

            # Compute gradients
            dw = (1 / n_samples) * np.dot(X.T, (y_predicted - y))
            db = (1 / n_samples) * np.sum(y_predicted - y)

            # Update parameters
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

            # Compute loss
            cost = -np.mean(y * np.log(y_predicted) + (1 - y) * np.log(1 - y_predicted))
            self.cost_history.append(cost)
            if (i % 100 == 0):
                print(f'Iteration {i}: Cost = {cost}')

    def predict(self, X):
        """
        Makes predictions using the trained logistic regression model.

        Parameters:
        - X: Test data, a NumPy array of shape (n_samples, n_features).

        Returns:
        - A NumPy array of predicted binary labels (0 or 1).
        """
        linear_model = np.dot(X, self.weights) + self.bias
        y_predicted = self.sigmoid(linear_model)
        return (y_predicted >= 0.5).astype(int)

    def normalize(self, X):
        """
        Normalizes the input data.

        Parameters:
        - X: Input data, a NumPy array of shape (n_samples, n_features).

        Returns:
        - Normalized data, a NumPy array of shape (n_samples, n_features).
        """
        return (X - X.mean(axis=0)) / X.std(axis=0)

