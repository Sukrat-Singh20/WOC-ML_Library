import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

class LinearRegression:
    def __init__(self, X, y, output_dim, learning_rate=0.01, iterations=1000):
        self.input = X
        self.y = y
        self.weight = np.random.randn(self.input.shape[1], output_dim)
        self.bias = np.zeros((1, output_dim))
        self.cost_history = []
        self.learning_rate = learning_rate
        self.iterations = iterations

    def clean_data(self, X, y):
        print("Are there any NaN values in X? ", np.isnan(X).any())
        print("Are there any NaN values in y? ", np.isnan(y).any())
        print("Are there any infinite values in X? ", np.isinf(X).any())
        print("Are there any infinite values in y? ", np.isinf(y).any())

        col_nan_mask = np.isnan(X).all(axis=0)  # Columns that are entirely NaN
        print("Columns entirely NaN:", np.where(col_nan_mask)[0])
        X = X[:, ~col_nan_mask]  # Drop these columns

        col_means = np.nanmean(X, axis=0)  # Compute column means, ignoring NaN
        inds = np.where(np.isnan(X))  # Find indices where NaN values exist
        X[inds] = np.take(col_means, inds[1])  # Replace NaN values with column means

        nan_columns = np.isnan(X).any(axis=0)  # Identify columns with any NaN values
        print("Columns with NaN values:", np.where(nan_columns)[0])

        print("Are there any NaN values in X after final cleaning? ", np.isnan(X).any())
        print("Feature-wise mean:\n", np.mean(X, axis=0))
        print("Feature-wise std deviation:\n", np.std(X, axis=0))
        print(f"Are there any NaN values in y? {np.any(np.isnan(y))}")

        valid_indices = ~np.isnan(y).flatten()  # Find rows without NaN in y
        X = X[valid_indices]
        y = y[valid_indices]

        print(f"Are there any NaN values in y after cleaning? {np.any(np.isnan(y))}")

        # Normalize input features
        from sklearn.preprocessing import StandardScaler
        scaler = StandardScaler()
        X_normalized = scaler.fit_transform(X)

        return (X_normalized, y)

    def cost(self):
        m = self.input.shape[0]
        z = np.dot(self.input, self.weight) + self.bias
        cost = (1/(2*m)) * np.sum((z - self.y) ** 2)
        return cost
    
    def train(self):
        self.input, self.y = self.clean_data(self.input, self.y)
        m = self.input.shape[0]
        for i in range(self.iterations):
            # Predictions
            predictions = np.dot(self.input, self.weight) + self.bias

            # Gradients
            dW = (1 / m) * np.dot(self.input.T, (predictions - self.y))
            db = (1 / m) * np.sum(predictions - self.y)

            # Update weights and bias
            self.weight -= self.learning_rate * dW
            self.bias -= self.learning_rate * db

            self.cost_history.append(self.cost())

            # Compute and log cost every 100 iterations
            if i % 100 == 0:
                cost = self.cost()
                print(f"Iteration {i}: Cost {cost}")

    def predict(self):
        predictions = np.dot(self.input, self.weight) + self.bias
        return predictions
    
    def visualize_predictions(self):
        # Make predictions
        predictions = self.predict()

        # Plot true vs predicted values
        plt.figure(figsize=(10, 6))
        plt.scatter(self.y, predictions, alpha=0.5, label="Predictions vs True")
        plt.xlabel("True Values")
        plt.ylabel("Predicted Values")
        plt.title("True vs Predicted Values")
        plt.legend()
        plt.show()

    def visualize_cost(self):
        # Plot cost vs iterations
        plt.plot(range(len(self.cost_history)), self.cost_history)
        plt.title("Cost vs Iterations")
        plt.xlabel("Iterations")
        plt.ylabel("Cost")
        plt.grid()
        plt.show()


# train_data = pd.read_csv('linear_regression_train.csv')
# X = train_data.drop(columns=['ID', 'Target']).values
# y = train_data['Target'].values.reshape(-1, 1)

# model = LinearRegression(X, y, output_dim=1, learning_rate=0.01, iterations=1000)
# model.train()
# model.visualize_predictions()
# model.visualize_cost()