import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

class TwoLayerNN:
    def __init__(self, X, y, hidden_size=128, learning_rate=0.01, epochs=100):
        self.input = X
        self.y = y
        self.hidden_size = hidden_size
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.load_data()
        self.initialize_weights()
    
    def load_data(self):
        # Normalize features
        self.X = (self.input - self.input.mean(axis=0)) / self.input.std(axis=0)
        
        # One-hot encode labels
        num_classes = len(np.unique(self.y))
        self.num_classes = num_classes
        y_one_hot = np.zeros((self.y.size, num_classes))
        y_one_hot[np.arange(self.y.size), self.y - 1] = 1  # Convert labels to zero-indexed
        
        # Split data into training and testing sets
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            self.X, y_one_hot, test_size=0.2, random_state=42
        )
    
    def initialize_weights(self):
        # Initialize weights and biases
        input_size = self.X.shape[1]
        output_size = self.num_classes
        
        np.random.seed(42)
        self.W1 = np.random.randn(input_size, self.hidden_size) * 0.01
        self.b1 = np.zeros((1, self.hidden_size))
        self.W2 = np.random.randn(self.hidden_size, output_size) * 0.01
        self.b2 = np.zeros((1, output_size))
    
    def relu(self, Z):
        return np.maximum(0, Z)
    
    def softmax(self, Z):
        exp_Z = np.exp(Z - np.max(Z, axis=1, keepdims=True))  # Stability trick
        return exp_Z / np.sum(exp_Z, axis=1, keepdims=True)
    
    def relu_derivative(self, Z):
        return Z > 0
    
    def forward_propagation(self, X):
        Z1 = np.dot(X, self.W1) + self.b1
        A1 = self.relu(Z1)
        Z2 = np.dot(A1, self.W2) + self.b2
        A2 = self.softmax(Z2)
        cache = (Z1, A1, Z2, A2)
        return A2, cache
    
    def backward_propagation(self, X, y, cache):
        Z1, A1, Z2, A2 = cache
        m = X.shape[0]
        
        dZ2 = A2 - y
        dW2 = np.dot(A1.T, dZ2) / m
        db2 = np.sum(dZ2, axis=0, keepdims=True) / m
        
        dA1 = np.dot(dZ2, self.W2.T)
        dZ1 = dA1 * self.relu_derivative(Z1)
        dW1 = np.dot(X.T, dZ1) / m
        db1 = np.sum(dZ1, axis=0, keepdims=True) / m
        
        return dW1, db1, dW2, db2
    
    def compute_loss(self, y, y_hat):
        m = y.shape[0]
        loss = -np.sum(y * np.log(y_hat + 1e-8)) / m  # Cross-entropy loss
        return loss
    
    def train(self):
        losses = []
        for epoch in range(self.epochs):
            # Forward pass
            y_hat, cache = self.forward_propagation(self.X_train)
            
            # Compute loss
            loss = self.compute_loss(self.y_train, y_hat)
            losses.append(loss)
            
            # Backward pass
            dW1, db1, dW2, db2 = self.backward_propagation(self.X_train, self.y_train, cache)
            
            # Update weights and biases
            self.W1 -= self.learning_rate * dW1
            self.b1 -= self.learning_rate * db1
            self.W2 -= self.learning_rate * dW2
            self.b2 -= self.learning_rate * db2
            
            # Print loss every 10 epochs
            if epoch % 10 == 0:
                print(f"Epoch {epoch}/{self.epochs}, Loss: {loss:.4f}")
        
        # Plot the loss curve
        plt.plot(losses)
        plt.title("Loss Curve")
        plt.xlabel("Epochs")
        plt.ylabel("Loss")
        plt.show()
    
    def predict(self, X):
        y_hat, _ = self.forward_propagation(X)
        return np.argmax(y_hat, axis=1) + 1  # Convert back to 1-indexed
    
    def evaluate(self):
        predictions = self.predict(self.X_test)
        true_labels = np.argmax(self.y_test, axis=1) + 1
        accuracy = np.mean(predictions == true_labels)
        print(f"Test Accuracy: {accuracy:.4f}")


# train_data = pd.read_csv("nn_train.csv")
# X_train = train_data.drop(columns=['ID', 'binary_label', 'class_label']).values
# y_train = train_data['class_label'].values

# nn = TwoLayerNN(X_train, y_train, hidden_size=128, learning_rate=0.01, epochs=100)

# nn.train()
# nn.evaluate()
