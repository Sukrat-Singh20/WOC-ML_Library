import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

class PolynomialRegression:
    def __init__(self, X, y, learning_rate=0.01, iterations=1000):
        self.X = X
        self.y = y
        self.learning_rate = learning_rate
        self.iterations = iterations
        self.coefficients = np.random.rand(self.X.shape[1])

    def create_polynomial_features(self, degree=2):
        """Generates polynomial features up to the specified degree."""
        if self.X is None:
            raise ValueError("Data not prepared. Call prepare_data() first.")
        
        self.X_poly = np.hstack([
            np.power(self.X, d) for d in range(1, degree + 1)
        ])
        print(f"Polynomial features created with degree {degree}.")
        print(f"Shape of polynomial features: {self.X_poly.shape}")

    def train_model(self):
        """Trains a simple linear regression model on the polynomial features."""
        if self.X_poly is None or self.y is None:
            raise ValueError("Polynomial features not created. Call create_polynomial_features() first.")
        
        # Add bias term (intercept)
        X_bias = np.hstack([np.ones((self.X_poly.shape[0], 1)), self.X_poly])
        
        # Compute coefficients using the Normal Equation
        self.coefficients = np.linalg.pinv(X_bias.T @ X_bias) @ X_bias.T @ self.y
        print("Model trained successfully.")
        print(f"Coefficients: {self.coefficients}")

    def predict(self, X):
        """Predicts target values for given features."""
        if self.coefficients is None:
            raise ValueError("Model not trained. Call train_model() first.")
        
        # Add bias term (intercept)
        X_bias = np.hstack([np.ones((X.shape[0], 1)), X])
        return X_bias @ self.coefficients
    

# def perform_eda(data):
#         """Performs basic exploratory data analysis."""
#         # Basic information
#         print("Data Info:")
#         print(data.info())
         
#         print("\nBasic Statistics:")
#         print(data.describe())
        
#         print("\nMissing Values:")
#         print(data.isnull().sum())
        
#         # Visualize distributions
#         columns = [col for col in data.columns if col not in ['ID']]
#         for column in columns:
#             plt.hist(data[column], bins=30, alpha=0.7, color='blue', label=column)
#             plt.title(f"Distribution of {column}")
#             plt.xlabel(column)
#             plt.ylabel("Frequency")
#             plt.show()
        
#         # Correlation matrix
#         print("\nCorrelation Matrix:")
#         correlation_matrix = data.drop(columns=["ID"]).corr()
#         print(correlation_matrix)
#         plt.imshow(correlation_matrix, cmap='coolwarm', interpolation='none')
#         plt.colorbar()
#         plt.title("Correlation Matrix")
#         plt.show()

# train_data = pd.read_csv('polynomial_regression_train.csv')
# perform_eda(train_data)

# X = train_data.drop(columns=['ID', 'Target']).values
# y = train_data['Target'].values
# print(f"X shape: {X.shape}, y shape: {y.shape}")

# model = PolynomialRegression(X, y)
# # model.create_polynomial_features(degree=2)
# model.train_model()